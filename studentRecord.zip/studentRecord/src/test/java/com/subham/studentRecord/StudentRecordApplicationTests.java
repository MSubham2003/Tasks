package com.subham.studentRecord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
