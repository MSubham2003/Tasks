package com.subham.studentRecord.controller;

import com.subham.studentRecord.entity.Student;
import com.subham.studentRecord.exception.StudentException;
import com.subham.studentRecord.model.Response;
import com.subham.studentRecord.service.StudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/students")
@Slf4j
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping()
    public ResponseEntity<Response> registerStudent(@RequestBody Student student) throws StudentException {
        log.info("Request hit in controller for Student registration {}", student);
        return ResponseEntity.status(201).body(studentService.registerNewStudent(student));
    }

    @GetMapping()
    public ResponseEntity<Response> getAllStudents(){
        log.info("Request hit in controller to get all Students");
        return ResponseEntity.ok(studentService.getAllStudents());
    }

    @GetMapping("{id}")
    public ResponseEntity<Response> getStudentById(@PathVariable Long id) throws StudentException {
        log.info("Request hit in controller to get data of student with Id: {}", id);
        return ResponseEntity.ok(studentService.getStudentById(id));
    }

    @PutMapping("{id}")
    public ResponseEntity<Response> updateStudentById(@PathVariable Long id, @RequestBody Student student) throws StudentException {
        log.info("Request hit in controller to update student details with id: {}, data: {}", id, student);
        return ResponseEntity.ok(studentService.updateStudentDetail(id, student));
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> deleteStudentById(@PathVariable Long id) throws StudentException {
        log.info("Request hit in controller to delete data of student with Id: {}", id);
        studentService.deleteStudentById(id);
        return ResponseEntity.status(204).build();
    }

    @GetMapping("department/{department}")
    public ResponseEntity<Response> getStudentsByDepartment(@PathVariable String department){
        log.info("Request hit in controller to get data of students with department: {}", department);
        return ResponseEntity.ok(studentService.fetchStudentByDepartment(department));
    }

}
