package com.subham.studentRecord.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.subham.studentRecord.entity.Student;
import lombok.Data;

import java.util.List;

@Data
public class Response {
    @JsonProperty("status")
    private String status;

    @JsonProperty("message")
    private String errMessage;

    @JsonProperty("data")
    private Object data;

    @JsonIgnore
    public void setStudentDataInList(List<Student> students) {
        if (students == null)
            this.data = "Null got in List.";
        ObjectMapper mapper = new ObjectMapper();
        this.data = mapper.convertValue(data, new TypeReference<List<Student>>() {});
    }

    @JsonIgnore
    public void setStudentData(Student dto) {
        if (dto == null)
            this.data = "Null got in object.";
        ObjectMapper mapper = new ObjectMapper();
        this.data = mapper.convertValue(data, Student.class);
    }
}
