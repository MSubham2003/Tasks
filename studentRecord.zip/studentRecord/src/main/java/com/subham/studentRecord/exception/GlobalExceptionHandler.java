package com.subham.studentRecord.exception;

import com.subham.studentRecord.model.Response;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final String STATUS = "FAILED";

    @ExceptionHandler({StudentException.class})
    public ResponseEntity<Response> handleRunTimeException(StudentException ex){
        Response res = new Response();
        res.setStatus(STATUS);
        res.setErrMessage(ex.getERROR_MESSAGE());
        HttpStatusCode httpStatusCode = ex.getHTTP_STATUS_CODE();
        return ResponseEntity.status(httpStatusCode).body(res);
    }

    @ExceptionHandler({Exception.class})
    public ResponseEntity<Response> handleException(Exception ex){
        Response res = new Response();
        res.setStatus(STATUS);
        res.setErrMessage(ex.getMessage());
        return ResponseEntity.status(500).body(res);
    }
}
